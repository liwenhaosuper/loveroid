package com.github.rtyley.android.sherlock.roboguice;

/**
 * Used by robolectric
 */
public class R {
}
